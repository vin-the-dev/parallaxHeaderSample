//
//  HeaderView.swift
//  parallaxHeaderSample
//
//  Created by Roshith Balendran on 15/11/15.
//  Copyright © 2015 Roshith Balendran. All rights reserved.
//

import UIKit

class HeaderView: UIView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    @IBOutlet weak internal var lblHeaderView: UILabel!

    @IBOutlet weak internal var imageView: UIImageView!
}

extension UIView {
    class func loadFromNibNamed(nibNamed: String, bundle : NSBundle? = nil) -> UIView? {
        return UINib(
            nibName: nibNamed,
            bundle: bundle
            ).instantiateWithOwner(nil, options: nil)[0] as? UIView
    }
}
